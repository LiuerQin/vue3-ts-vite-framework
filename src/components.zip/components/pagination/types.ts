export interface PageData {
  total: number;
  pageSize: number;
  currentPage: number;
}
