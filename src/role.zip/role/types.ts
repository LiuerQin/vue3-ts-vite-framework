// interface
export interface FData {
  roleName: string;
  mark: string;
  menus: Array<string>;
}
